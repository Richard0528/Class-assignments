/*
 * TCSS 305
 * An example to demonstrate the use of the observer pattern.
 */

package observer;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;

/**
 * An action class for the decrement action.
 * 
 * @author Alan Fowler
 * @version 1.3
 */
public class DecrementAction extends AbstractAction {
    
    /** A generated version ID for Serialization. */
    private static final long serialVersionUID = -4569301000506226603L;
    
    /**
     * The int to be decremented.
     */
    private final ObservableInteger myInt;

    /**
     * Constructs a new DecrementAction.
     * 
     * @param theInt The int to be decremented.
     */
    public DecrementAction(final ObservableInteger theInt) {
        super("Decrement");
        myInt = theInt;
    }

    /**
     * The method called when the action is performed.
     * 
     * @param theEvent The event that caused the action to be performed.
     */
    public void actionPerformed(final ActionEvent theEvent) {
        myInt.decrementRandom();
    }
}

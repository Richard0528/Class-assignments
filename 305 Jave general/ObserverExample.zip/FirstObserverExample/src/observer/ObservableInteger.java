/*
 * TCSS 305
 * An example to demonstrate the use of the observer pattern.
 */

package observer;

import java.util.Observable;
import java.util.Random;

/**
 * An observable Integer that notifies its observers with its new value whenever
 * its value changes.
 * 
 * @author Alan Fowler
 * @version 1.3
 */
public class ObservableInteger extends Observable {
    
    // Instance Fields

    /**
     * The actual int value encapsulated by this Observable.
     */
    private int myValue;

    /**
     * A Random used by this Observable.
     */
    private final Random myRandom = new Random();

    // Instance Methods

    /**
     * Increments the long value by some random long.
     */
    public void incrementRandom() {
        final int temp = myRandom.nextInt(IntGUI.MAX_CHANGE);

        // if adding temp to my_value does not result in an overflow
        if (myValue + temp > myValue) {
            myValue = myValue + temp;
            setChanged();  // the value changed so set the flag          
        }

        notifyObservers(myValue);  // send a notification if there was a change
    }

    /**
     * Decrements the long value by some random long.
     */
    public void decrementRandom() {
        final int temp = myRandom.nextInt(IntGUI.MAX_CHANGE);

        // if subtracting temp from my_value does not result in an underflow
        if (myValue - temp < myValue) {
            myValue = myValue - temp;
            setChanged(); // the value changed so set the flag
        }

        notifyObservers(myValue); // send a notification if there was a change
    }

    /**
     * @return the int value.
     */
    public int getValue() {
        return myValue;
    }
}

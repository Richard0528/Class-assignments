/*
 * TCSS 305
 * An example to demonstrate the use of the observer pattern.
 */

package observer;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;

/**
 * An action class for the increment action.
 * 
 * @author Alan Fowler
 * @version 1.2
 */
@SuppressWarnings("serial")
public class IncrementAction extends AbstractAction {
    /**
     * The int to be decremented.
     */
    private final ObservableInteger myInt;

    /**
     * Constructs a new IncrementAction.
     * 
     * @param theInt The int to be decremented.
     */
    public IncrementAction(final ObservableInteger theInt) {
        super("Increment");
        myInt = theInt;
    }

    /**
     * The method called when the action is performed.
     * 
     * @param theEvent The event that caused the action to be performed.
     */
    public void actionPerformed(final ActionEvent theEvent) {
        myInt.incrementRandom();
    }
}

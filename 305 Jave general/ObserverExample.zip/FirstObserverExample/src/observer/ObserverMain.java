/*
 * TCSS 305
 * An example to demonstrate the use of the observer pattern.
 */

package observer;

import java.awt.EventQueue;

/**
 * Starts the Observer code example.
 * 
 * @author Alan Fowler
 * @version 1.2
 */
public final class ObserverMain {
    
    /** Private constructor to inhibit external instantiation. */
    private ObserverMain() {
        // do nothing
    }

    /**
     * The start point for the program.
     * 
     * @param theArgs command line arguments - ignored in this program
     */
    public static void main(final String[] theArgs) {
        
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                // create the Observable
                final ObservableInteger oi = new ObservableInteger();
                
                // create the Observer
                final IntGUI view = new IntGUI(new IncrementAction(oi),
                                               new DecrementAction(oi));
                // register the Observer
                oi.addObserver(view);
                
                view.start(); // start the GUI
            }
        });
    }

}

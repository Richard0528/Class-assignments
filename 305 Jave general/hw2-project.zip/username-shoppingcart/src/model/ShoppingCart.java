// Finish and comment me!
// Add whatever fields you think are necessary.

package model;

import java.math.BigDecimal;

public class ShoppingCart {


    public ShoppingCart() {

    }


    public void add(final ItemOrder theOrder) {
        
    }


    public void setMembership(final boolean theMembership) {
        
    }


    public BigDecimal calculateTotal() {

        return null;
    }
    
    public void clear() {
        
    }

    @Override
    public String toString() {
        
        return null;
    }

}

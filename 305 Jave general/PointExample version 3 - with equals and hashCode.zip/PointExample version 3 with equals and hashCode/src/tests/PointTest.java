/*
 * Unit test demo code for TCSS 305
 */

package tests;

import static org.junit.Assert.*;

import java.awt.Color;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import shapes.Point;

/**
 * Tests of the Point class.
 * 
 * @author Alan Fowler
 * @version 1,1
 */
public class PointTest {
    
    /*
     * NOTE about double values and unit tests:
     * 
     * There is no clean way to compare primitive doubles or floats for equality.
     * Floating point calculations are not exact - there are often round-off errors
     * and errors due to imprecise representation in memory.
     * (For example, 0.1 cannot be exactly represented in binary floating point.)
     * Because of this, directly comparing two floating point values for equality is
     * usually not a good idea, because they can be different by a small amount,
     * depending upon how they were computed.
     * 
     * assertEquals provides an overloaded version which accepts an 'epsilon' value
     * or 'tolerance' to use when comparing primitive floating point values for equality.
     * Below I declare a constant to be used throughout this test class whenever there is a
     * need to compare floating point values for equality.
     */
    
    /** A tolerance used when comparing double values for equality. */
    private static final double TOLERANCE = .000001;

    // using a Rule in tests requires a public field
    /** An expected exception rule that can be used in tests where exceptions are expected. */
    @Rule
    public final ExpectedException myThrown = ExpectedException.none();
    
    // The test fixture. The Objects I will use in the tests.
    /** A Point to use in the tests. */
    private Point myPoint;
    

    /**
     * A method to initialize the test fixture before each test.
     */
    @Before // This method runs before EACH test method.
    public void setUp() { // no need to throw any exceptions!
        myPoint = new Point();
    }
    
    

    
    
//    /*
//     * The next 2 methods check that the copy constructor throws an exception when
//     * a null value is passed in. There is no reason to write 2 tests for the same thing
//     * except that I wanted to demonstrate 2 ways of doing this. Choose one.
//     */
//    
//    // test for an exception using the 'expected =' syntax
//    /**
//     * Test of the copy constructor when the parameter is null.
//     */
//    @Test(expected = NullPointerException.class)
//    public void testCopyConstructorNull() {
//        new Point(null);
//    }
//    
//    // test for an exception using an expected exception rule
//    /**
//     * Test of the copy constructor when the parameter is null.
//     */
//    @Test
//    public void testCopyConstructorNull2() {
//        myThrown.expect(NullPointerException.class);
//        new Point(null);
//    }
    
    
    

    /**
     * Test method for {@link Point#calculateDistance(Point)}.
     */
    @Test
    public void testCalculateDistance() {
        assertEquals("testCalculateDistance failed!", 5,
                     myPoint.calculateDistance(new Point(3, 4)), TOLERANCE);

        assertEquals("testCalculateDistance failed!", 5,
                     myPoint.calculateDistance(new Point(-3, -4)), TOLERANCE);

        assertEquals("testCalculateDistance failed!", 0,
                     myPoint.calculateDistance(new Point(myPoint)), TOLERANCE);
    }

    /**
     * Test method for calculateDistance(Point) when the parameter is null}.
     */
    @Test(expected = NullPointerException.class)
    public void testCalculateDistanceNull() {
        // No assertion is needed when testing an expected exception.
        // Just call code which should result in the expected exception.
        myPoint.calculateDistance(null);
    }
    
    /**
     * Test method for {@link Point#setLocation(double, double)}.
     */
    @Test
    public void testSetLocation() {
        myPoint.setLocation(13, 42);
        
        /*
         * Remember that primitive types double and float are stored imprecisely;
         * therefore, your tests must include a tolerance.
         */
        
        assertEquals("setLocation failed to set the x value correctly!",
                     13, myPoint.getX(), TOLERANCE);
        
        assertEquals("setLocation failed to set the y value correctly!",
                     42, myPoint.getY(), TOLERANCE);
    }
    
    /**
     * Test method for {@link Point#getRho()}.
     */
    @Test
    public void testGetRho() {
        final Point p1 = new Point(3.0, 4.0);
        
        assertEquals("getRho() failed!", 5.0, p1.getRho(), TOLERANCE);
    }
    
    /**
     * Test method for {@link Point#getThetaInRadians()}.
     */
    @Test
    public void testGetThetaInRadians() {
        final Point p1 = new Point(10.0, 10.0);
        
        assertEquals("getThetaInRadians() failed!",
                     Math.atan(1), p1.getThetaInRadians(), TOLERANCE);
    }
    
    /**
     * Test method for {@link Point#getThetaInDegrees()}.
     */
    @Test
    public void testGetThetaInDegrees() {
        final Point p1 = new Point(10.0, 10.0);
        
        assertEquals("getThetaInDegrees() failed!",
                     45.0, p1.getThetaInDegrees(), TOLERANCE);
    }

    /**
     * Test method for {@link Point#translate(double, double)}.
     */
    @Test
    public void testTranslate() {
        myPoint.translate(10, -5);
        assertEquals("translate failed!", 10, myPoint.getX(), TOLERANCE);
        assertEquals("translate failed!", -5, myPoint.getY(), TOLERANCE);
    }
    
    /** Test of the equals() method. */
    @Test
    public void testEquals() {
        // an object is equal to itself - reflexive property
        assertEquals("equals() fails a test of the reflexive property.", myPoint, myPoint);

        // .equals() should return false if the parameter is null        
        assertNotEquals("equals() fails to return false when passed a null parameter",
                        myPoint, null);

        // .equals() should return false if the parameter is a different type
        assertNotEquals("equals() fails to return false when passed the wrong parameter type",
                    myPoint, new Color(10, 20, 30));

        // the symmetric property should hold
        final Point point2 = new Point(); // location (0, 0) same as myPoint
        assertEquals("equals() fails a test of the symmetric property.",
                     myPoint, point2);
        assertEquals("equals() fails a test of the symmetric property.",
                     point2, myPoint);

        // Points with different x coordinates should not be considered equal
        assertFalse("equals() fails to return false when x coordinates do not match.",
                    myPoint.equals(new Point(1, 0)));

        // Points with different y coordinates should not be considered equal
        assertFalse("equals() fails to return false when y coordinates do not match.",
                    myPoint.equals(new Point(0, 1)));
    }

    /**
     * Test method for {@link Point#toString()}.
     */
    @Test
    public void testToString() {
        assertEquals("toString() produced an unexpected result!",
                     "Point (0.00, 0.00)", myPoint.toString());
    }
    
    /** Test of the hashCode() method. */
    @Test
    public void testHashCode() {
        // Equal objects should have equal hashCode values.
        final Point point2 = new Point();

        assertEquals("hashCode() fails to produce identical values for"
                        + " equal ImmutablePoints",
                     myPoint.hashCode(), point2.hashCode());
    }
    
    
    /**
     * Test method to demonstrate some other assertions.
     */
    @Test
    public void testOther() {
        /*
         *  Here are some additional (unnecessary) tests
         *  just to demonstrate some other assertions:
         */
        
        assertSame("These are the same object!", myPoint, myPoint);
        assertNotSame("These are NOT the same object!", myPoint, new Point(myPoint));
        
        Point point2 = null;
        assertNull("point2 should be null!", point2);
        point2 = new Point();
        assertNotNull("point2 should not be null!", point2);
        
        myPoint.setLocation(42, 42);
        assertTrue("This expression should be true!", myPoint.getX() > 0);
        assertFalse("This expression should be false!", myPoint.getX() < 0);
    }

}

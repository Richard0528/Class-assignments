// finish and comment me!

package gui;

/**
 * 
 * @author ???
 * @version ???
 */
public class SnapShopGUI {
    
    /**
     * 
     */
    public void start() {
        javax.swing.JOptionPane.showMessageDialog(null, "SnapShop placeholder");
    }
}